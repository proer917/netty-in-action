/**
 * Created by kerr.
 *
 * Listing 9.2 Testing the FixedLengthFrameDecoder {@link nia.test.chapter9.FixedLengthFrameDecoderTest}
 *
 * Listing 9.4 Testing the AbsIntegerEncoder {@link nia.test.chapter9.AbsIntegerEncoderTest}
 *
 * Listing 9.6 Testing FrameChunkDecoder {@link nia.test.chapter9.FrameChunkDecoderTest}
 */
package nia.test.chapter9;
/**
 * Created by kerr.
 *
 * Listing 9.1 FixedLengthFrameDecoder {@link nia.chapter9.FixedLengthFrameDecoder}
 *
 * Listing 9.3 AbsIntegerEncoder {@link nia.chapter9.AbsIntegerEncoder}
 *
 * Listing 9.5 FrameChunkDecoder {@link nia.chapter9.FrameChunkDecoder}
 */
package nia.chapter9;
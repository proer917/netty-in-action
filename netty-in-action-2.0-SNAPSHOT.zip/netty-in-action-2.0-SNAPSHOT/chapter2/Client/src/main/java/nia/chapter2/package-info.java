/**
 * Created by kerr.
 *
 * Listing 2.3 ChannelHandler for the client {@link nia.chapter2.echoclient.EchoClientHandler}
 *
 * Listing 2.4 Main class for the client {@link nia.chapter2.echoclient.EchoClient}
 */
package nia.chapter2;
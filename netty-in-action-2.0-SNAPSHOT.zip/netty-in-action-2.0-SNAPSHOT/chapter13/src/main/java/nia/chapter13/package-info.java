/**
 * Created by kerr.
 *
 * Listing 13.1 LogEvent message {@link nia.chapter13.LogEvent}
 *
 * Listing 13.2 LogEventEncoder {@link nia.chapter13.LogEventEncoder}
 *
 * Listing 13.3 LogEventBroadcaster {@link nia.chapter13.LogEventBroadcaster}
 *
 * Listing 13.6 LogEventDecoder {@link nia.chapter13.LogEventDecoder}
 *
 * Listing 13.7 LogEventHandler {@link nia.chapter13.LogEventHandler}
 *
 * Listing 13.8 LogEventMonitor {@link nia.chapter13.LogEventMonitor}
 */
package nia.chapter13;